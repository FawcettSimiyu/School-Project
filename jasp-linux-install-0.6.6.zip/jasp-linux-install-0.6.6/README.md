Install JASP on Debian/Ubuntu 14.10+
====================================

To install [JASP](https://jasp-stats.org/) just download [this script](https://raw.githubusercontent.com/lindemann09/jasp-linux-install/master/install_jasp.sh)
and execute it as sudo. Like this:

```
wget -P /tmp https://raw.githubusercontent.com/lindemann09/jasp-linux-install/master/install_jasp.sh
sudo sh /tmp/install_jasp.sh
```



